using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSwitcher : MonoBehaviour
{
    public Camera mainCamera;
    public Camera camera2;

    void Start()
    {
        // Makes sure only the main camera is active at the start
        mainCamera.enabled = true;
        camera2.enabled = false;
    }

    void Update()
    {
        // Check for input to switch between cameras
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            SwapCameras();
        }
    }

    void SwapCameras()
    {
        // Swap the active state of the cameras
        mainCamera.enabled = !mainCamera.enabled;
        camera2.enabled = !camera2.enabled;
    }
}