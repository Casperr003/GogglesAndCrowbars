using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportPlayer : MonoBehaviour
{
    public Vector3 teleportCoordinates = new Vector3(1f, 1f, 1f); // Specify the teleport coordinates in the Inspector

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger entered!"); // Check if OnTriggerEnter is being called

        // Check if the overlapping object is the player
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player detected!"); // Check if the player is detected

            // Teleport the player to the specified coordinates
            other.transform.position = teleportCoordinates;

            Debug.Log("Player teleported to: " + teleportCoordinates); // Check if the player is teleported
        }
    }
}


