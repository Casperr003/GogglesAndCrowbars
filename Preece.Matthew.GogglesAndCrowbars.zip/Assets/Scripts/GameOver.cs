using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCollision : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Collision Detected with: " + other.gameObject.name); // Check what object is being collided with
        Debug.Log("Layer of collided object: " + LayerMask.LayerToName(other.gameObject.layer)); // Check the layer of the collided object

        // Check if the collided object is on the "Goggles" layer
        if (other.gameObject.layer == LayerMask.NameToLayer("Goggles"))
        {
            // Game over
            Debug.Log("Game Over!");
            // Restart the game (Reload the current scene)
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}


