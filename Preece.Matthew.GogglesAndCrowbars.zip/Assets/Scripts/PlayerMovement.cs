using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonController : MonoBehaviour
{
    public GameObject teleportCube; // Reference to the TeleportCube object
    public float speed = 5.0f; // Speed of movement
    public float sensitivity = 2.0f; // Mouse sensitivity

    private CharacterController characterController;
    private float rotationX = 0;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked; // Lock cursor to center of screen
    }

    void Update()
    {
        // Mouse input for looking around
        float mouseX = Input.GetAxis("Mouse X") * sensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * sensitivity;

        // Rotate the player around the Y axis (left and right)
        transform.Rotate(0, mouseX, 0);

        // Calculate rotation for looking up and down
        rotationX -= mouseY;
        rotationX = Mathf.Clamp(rotationX, -90f, 90f);

        // Rotate the camera (player's child object) around the X axis (up and down)
        Camera.main.transform.localRotation = Quaternion.Euler(rotationX, 0, 0);

        // Movement input
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        // Calculate movement direction based on player's current rotation
        Vector3 moveDirection = transform.right * moveHorizontal + transform.forward * moveVertical;

        // Apply movement
        characterController.Move(moveDirection * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        // Check if the overlapping object is the player
        if (other.CompareTag("Player"))
        {
            // Check if the collider's parent object is the specific object you want to teleport from
            if (other.transform.parent != null && other.transform.parent.gameObject == teleportCube)
            {
                // Teleport the player to the specified coordinates
                TeleportPlayer();
            }
        }
    }

    private void TeleportPlayer()
    {
        // Disable Character Controller to directly set position
        characterController.enabled = false;
        // Teleport the player to the specified coordinates
        transform.position = new Vector3(1f, 1f, 1f);
        // Re-enable Character Controller
        characterController.enabled = true;
    }
}

