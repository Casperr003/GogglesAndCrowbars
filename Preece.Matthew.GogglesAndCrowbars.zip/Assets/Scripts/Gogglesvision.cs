using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectVisibility : MonoBehaviour
{
    public Camera specificCamera;

    void Start()
    {
        // Create a new layer named "Goggles" if it doesn't exist
        int gogglesLayer = LayerMask.NameToLayer("Goggles");
        if (gogglesLayer == -1)
        {
            gogglesLayer = LayerMask.NameToLayer("Goggles");
        }

        // Assign the object to the "Goggles" layer
        gameObject.layer = gogglesLayer;

        // Set the culling mask of the specific camera to include only the "Goggles" layer
        if (specificCamera != null)
        {
            specificCamera.cullingMask = 1 << gogglesLayer;
        }
        else
        {
            Debug.LogWarning("Specific camera not assigned to the script.");
        }
    }
}

