using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemCollector : MonoBehaviour
{
    public int scoreValue = 10; // Score value of the collected item

    private bool isCollected = false; // Flag to track if the item has been collected

    // Method to collect the item
    public void CollectItem()
    {
        if (!isCollected)
        {
            // Add score
            ScoreManager.Instance.AddScore(scoreValue);

            // Remove the item from the game
            Destroy(gameObject);

            // Set the flag to indicate that the item has been collected
            isCollected = true;
        }
    }
}


