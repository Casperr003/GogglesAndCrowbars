using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    public float interactDistance = 3f;
    public LayerMask interactableLayer;
    public KeyCode interactKey = KeyCode.E;
    public Color interactableColor = Color.green;
    public Color nonInteractableColor = Color.white;
    public float glowIntensity = 2f;

    private GameObject currentInteractableObject;
    private Renderer currentInteractableRenderer;
    private Material originalMaterial;
    private Color originalColor;

    void Update()
    {
        // Cast a ray from the camera forward direction to detect interactable objects
        RaycastHit hit;
        if (Physics.Raycast(Camera.main.transform.position, Camera.main.transform.forward, out hit, interactDistance, interactableLayer))
        {
            GameObject hitObject = hit.collider.gameObject;

            // Check if the object is different from the current interactable object
            if (hitObject != currentInteractableObject)
            {
                // Reset color of the previous interactable object
                if (currentInteractableRenderer != null)
                    currentInteractableRenderer.material = originalMaterial;

                // Update the current interactable object
                currentInteractableObject = hitObject;
                currentInteractableRenderer = hitObject.GetComponent<Renderer>();

                // Change the material color and emission intensity of the new interactable object
                if (currentInteractableRenderer != null)
                {
                    originalMaterial = currentInteractableRenderer.material;
                    originalColor = originalMaterial.color;
                    Material newMaterial = new Material(originalMaterial);
                    newMaterial.color = interactableColor;
                    newMaterial.EnableKeyword("_EMISSION");
                    newMaterial.SetColor("_EmissionColor", interactableColor * glowIntensity);
                    currentInteractableRenderer.material = newMaterial;
                }
            }

            // Check if the player presses the interact key
            if (Input.GetKeyDown(interactKey))
            {
                // Check if the current interactable object has the ItemCollector component
                ItemCollector itemCollector = hitObject.GetComponent<ItemCollector>();
                if (itemCollector != null)
                {
                    // Perform interaction with the current interactable object
                    itemCollector.CollectItem();
                }
            }

            // Debug log to indicate interaction with an object
            Debug.Log("Interacting with: " + hitObject.name);
        }
        else
        {
            // Reset color of the previous interactable object if no interactable object is hit
            if (currentInteractableRenderer != null)
            {
                currentInteractableRenderer.material = originalMaterial;
                currentInteractableRenderer = null;
                currentInteractableObject = null;
            }
        }
    }
}




